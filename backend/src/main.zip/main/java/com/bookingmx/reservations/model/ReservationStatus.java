package com.bookingmx.reservations.model;

public enum ReservationStatus {
    ACTIVE, CANCELED
}
